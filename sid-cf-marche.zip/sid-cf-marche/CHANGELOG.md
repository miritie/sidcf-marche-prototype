# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

## [1.0.0] - 2024-11-11

### Ajouté
- ✅ Tableau de bord avec statistiques en temps réel
- ✅ Module de gestion des marchés (CRUD complet)
- ✅ Import et gestion du PPM (Plan de Passation des Marchés)
- ✅ Module de demandes d'achat
- ✅ Système de décision du Contrôleur Financier (Visa/Réserve/Refus)
- ✅ Suivi d'exécution (OS, décomptes, avenants)
- ✅ Gestion des garanties et réceptions
- ✅ Module de paramétrage complet
- ✅ Système de reporting et statistiques
- ✅ Filtres et recherche sur tous les tableaux
- ✅ Modales interactives pour détails et actions
- ✅ Charte graphique moderne et responsive
- ✅ Validation des règles de gestion métier
- ✅ Données de démonstration complètes

### Fonctionnalités métier implémentées

#### Planification (ECR-01)
- Import PPM depuis Excel (simulation)
- Création manuelle de marchés
- Gestion des fiches marchés avec livrables
- Localisation géographique des livrables

#### Contractualisation (ECR-02)
- Enregistrement des procédures
- Suivi des recours
- Observations du Contrôleur Financier

#### Attribution (ECR-03)
- Saisie des attributaires
- Décision CF avec motifs codifiés
- Échéancier de paiement
- Clé de répartition budgétaire

#### Exécution (ECR-04)
- Ordres de service
- Décomptes et paiements
- Avenants avec seuils d'alerte
- Garanties financières
- Résiliations

#### Clôture (ECR-05)
- Réceptions provisoire et définitive
- Mainlevée des garanties
- Synthèse finale du marché

#### Reporting (ECR-06)
- Tableau de bord consolidé
- Indicateurs de performance
- Filtres multi-critères
- Exports (prévu)

### Règles de gestion
- ✅ Blocage exécution sans Visa CF
- ✅ Seuils d'alerte avenants (25% et 30%)
- ✅ Contrôles de cohérence budgétaire
- ✅ Validation des garanties avant mainlevée
- ✅ Traçabilité complète des décisions

### Technique
- Architecture SPA (Single Page Application)
- Vanilla JavaScript (pas de dépendances lourdes)
- Système de routage simple
- State management centralisé
- Données JSON persistantes (prêt Airtable)
- Design responsive mobile-first
- Charte graphique paramétrable via CSS variables

### Documentation
- README complet avec guide d'installation
- Guide de déploiement détaillé
- Documentation des règles de gestion
- Exemples de données
- Structure du projet expliquée

## [À venir] - Prochaines versions

### [1.1.0] - Prévu
- [ ] Authentification utilisateurs
- [ ] Gestion des rôles et permissions
- [ ] Upload réel de fichiers
- [ ] Génération PDF des rapports
- [ ] Notifications email

### [1.2.0] - Prévu
- [ ] Intégration Airtable complète
- [ ] API REST pour intégrations
- [ ] Workflow d'approbation avancé
- [ ] Signature électronique
- [ ] Archive et historique

### [2.0.0] - Vision
- [ ] Module Budget intégré
- [ ] Module Contrôle a posteriori
- [ ] Dashboard analytique avancé
- [ ] BI et dataviz
- [ ] Application mobile native
- [ ] Mode hors-ligne (PWA)

---

## Types de modifications

- **Ajouté**: pour les nouvelles fonctionnalités
- **Modifié**: pour les changements dans les fonctionnalités existantes
- **Déprécié**: pour les fonctionnalités qui seront bientôt supprimées
- **Supprimé**: pour les fonctionnalités supprimées
- **Corrigé**: pour les corrections de bugs
- **Sécurité**: en cas de vulnérabilités
