# 🚀 Guide de Déploiement Rapide

## Option 1: Déploiement sur Vercel (Recommandé)

### Étape 1: Créer un repository GitHub

1. Aller sur https://github.com/new
2. Nom du repository: `sid-cf-marche`
3. Visibilité: Public ou Private
4. Créer le repository

### Étape 2: Pousser le code sur GitHub

```bash
# Dans le dossier du projet
git init
git add .
git commit -m "Initial commit - SID-CF Module Marché"
git branch -M main
git remote add origin https://github.com/VOTRE-USERNAME/sid-cf-marche.git
git push -u origin main
```

### Étape 3: Déployer sur Vercel

1. Aller sur https://vercel.com/signup
2. Créer un compte (avec GitHub)
3. Cliquer sur "New Project"
4. Importer votre repository `sid-cf-marche`
5. Configuration détectée automatiquement
6. Cliquer sur "Deploy"

🎉 **Votre application est en ligne !**

L'URL sera: `https://sid-cf-marche-XXXX.vercel.app`

### Étape 4: Configuration du domaine personnalisé (optionnel)

1. Dans le dashboard Vercel du projet
2. Settings > Domains
3. Ajouter votre domaine
4. Suivre les instructions DNS

## Option 2: Déploiement sur GitHub Pages

### Configuration

1. Dans votre repository GitHub
2. Settings > Pages
3. Source: Deploy from a branch
4. Branch: `main`, Folder: `/ (root)`
5. Save

Votre site sera disponible à:
`https://VOTRE-USERNAME.github.io/sid-cf-marche/`

## Option 3: Déploiement sur Netlify

### Via Interface Web

1. Aller sur https://app.netlify.com/start
2. Connecter GitHub
3. Sélectionner le repository
4. Deploy site

### Via CLI

```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

## Option 4: Hébergement traditionnel (Apache/Nginx)

1. Zipper tout le dossier
2. Uploader sur votre serveur
3. Extraire dans le dossier web (ex: `/var/www/html/`)
4. Configurer le virtual host

```nginx
# Exemple Nginx
server {
    listen 80;
    server_name votre-domaine.com;
    root /var/www/html/sid-cf-marche;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## 📝 Personnalisation avant déploiement

### 1. Changer le logo

Remplacer `assets/logo.svg` par votre logo

### 2. Ajuster les couleurs

Dans `css/styles.css`, modifier:
```css
:root {
  --primary-green: #4a7c59;  /* Votre couleur */
}
```

### 3. Adapter les données

Modifier les fichiers dans `data/`:
- `referentiels.json`
- `marches.json`  
- `ppm.json`

### 4. Mettre à jour les informations

Dans `index.html`:
- Nom d'utilisateur
- Rôle
- Titre de l'application

## 🔄 Mises à jour

### Avec Vercel/Netlify

Chaque push sur GitHub déploie automatiquement:

```bash
git add .
git commit -m "Mise à jour: description"
git push
```

### Avec hébergement traditionnel

1. Modifier localement
2. Re-zipper
3. Uploader
4. Extraire

## 🐛 Dépannage

### Le site ne charge pas

1. Vérifier la console du navigateur (F12)
2. Vérifier les chemins des fichiers
3. Vérifier les CORS si API externe

### Les données ne s'affichent pas

1. Vérifier que les fichiers JSON sont valides
2. Vérifier la console pour erreurs
3. Vérifier les chemins dans `app.js`

### Erreur CORS

Si hébergement local:
```bash
# Chrome
chrome --disable-web-security --user-data-dir=/tmp/chrome

# Firefox: about:config
security.fileuri.strict_origin_policy = false
```

Mieux: utiliser un serveur local (Python, Node, etc.)

## 📊 Monitoring

### Google Analytics (optionnel)

Ajouter dans `index.html` avant `</head>`:

```html
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

## 🔒 Sécurité Production

Pour un déploiement production:

1. ✅ Ajouter authentification
2. ✅ HTTPS obligatoire  
3. ✅ Validation côté serveur
4. ✅ Limitation des requêtes
5. ✅ Logs et monitoring
6. ✅ Backup réguliers

## 📞 Support

En cas de problème:
1. Vérifier la documentation
2. Consulter les logs Vercel/Netlify
3. Ouvrir une issue GitHub
4. Contacter l'équipe dev

---

**Bon déploiement ! 🚀**
