# 🎨 Guide de Personnalisation du Logo

## Remplacement Rapide du Logo

### Méthode 1: Remplacer le fichier SVG (Recommandé)

1. Préparez votre logo au format SVG
2. Renommez-le `logo.svg`
3. Remplacez le fichier dans `assets/logo.svg`
4. Rafraîchissez la page

**Avantages SVG:**
- ✅ Qualité parfaite à toute taille
- ✅ Fichier léger
- ✅ Modifiable avec code
- ✅ Support transparent

### Méthode 2: Utiliser PNG/JPG

1. Préparez votre logo (recommandé: 150x50 pixels, fond transparent)
2. Placez-le dans `assets/` (ex: `logo.png`)
3. Modifiez `index.html` ligne 10:

```html
<!-- Avant -->
<img src="assets/logo.svg" alt="SID-CF Logo" class="logo">

<!-- Après -->
<img src="assets/logo.png" alt="SID-CF Logo" class="logo">
```

### Méthode 3: Logo en ligne

Si votre logo est hébergé ailleurs:

```html
<img src="https://votresite.com/logo.png" alt="SID-CF Logo" class="logo">
```

## Ajuster la Taille du Logo

Dans `css/styles.css`, ligne ~35:

```css
.logo {
  height: 50px;  /* Modifier cette valeur */
  width: auto;   /* Garder les proportions */
}
```

**Exemples:**
- Petit logo: `height: 35px`
- Logo moyen: `height: 50px` (actuel)
- Grand logo: `height: 70px`

## Créer un Logo Simple avec Texte

Si vous n'avez pas de logo, utilisez du texte:

1. Supprimez la balise `<img>` dans `index.html`
2. Remplacez par:

```html
<div class="logo-text">
  <span class="logo-title">VOTRE SIGLE</span>
  <span class="logo-subtitle">Votre organisation</span>
</div>
```

3. Ajoutez dans `css/styles.css`:

```css
.logo-text {
  display: flex;
  flex-direction: column;
}

.logo-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: white;
}

.logo-subtitle {
  font-size: 0.8rem;
  opacity: 0.9;
  color: white;
}
```

## Générateurs de Logo en Ligne (Gratuits)

Si vous devez créer un logo rapidement:

1. **Canva**: https://www.canva.com/create/logos/
2. **LogoMakr**: https://logomakr.com/
3. **Hatchful**: https://www.shopify.com/tools/logo-maker
4. **Figma**: https://www.figma.com/ (gratuit)

**Conseils:**
- Préférez des designs simples et professionnels
- Utilisez 1-2 couleurs maximum
- Assurez-vous de la lisibilité en petit format
- Exportez en SVG si possible

## Convertir votre Logo en SVG

Si vous avez un PNG/JPG et voulez du SVG:

1. **Vectorizer.AI**: https://vectorizer.ai/
2. **Convertio**: https://convertio.co/png-svg/
3. **SVGator**: https://www.svgator.com/tools/image-to-svg

## Logo Responsive (Mobile)

Pour un logo différent sur mobile:

Dans `css/styles.css`:

```css
/* Logo desktop */
.logo {
  height: 50px;
}

/* Logo mobile */
@media (max-width: 768px) {
  .logo {
    height: 35px;  /* Plus petit sur mobile */
  }
  
  .app-title {
    font-size: 1.2rem;  /* Titre plus petit */
  }
}
```

## Changer les Couleurs du Header

Le logo fait partie du header. Pour changer les couleurs:

Dans `css/styles.css`, ligne ~21:

```css
.header {
  background: linear-gradient(135deg, 
    #4a7c59 0%,      /* Couleur 1 */
    #3a6449 100%     /* Couleur 2 */
  );
  /* ... */
}
```

**Exemples de palettes:**

Bleu professionnel:
```css
background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
```

Vert moderne:
```css
background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
```

Rouge dynamique:
```css
background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%);
```

## Position du Logo

Par défaut, le logo est à gauche. Pour le centrer:

Dans `css/styles.css`:

```css
.header-content {
  display: flex;
  justify-content: center;  /* Au lieu de space-between */
  align-items: center;
}
```

## Logo avec Lien

Pour rendre le logo cliquable (retour accueil):

Dans `index.html`:

```html
<a href="/" class="logo-link">
  <img src="assets/logo.svg" alt="SID-CF Logo" class="logo">
</a>
```

Dans `css/styles.css`:

```css
.logo-link {
  display: inline-block;
  text-decoration: none;
}

.logo-link:hover .logo {
  opacity: 0.8;
  transition: opacity 0.3s;
}
```

## Vérifier le Résultat

Après modification:

1. ✅ Vérifier sur desktop (Chrome, Firefox, Safari)
2. ✅ Vérifier sur mobile (responsive design)
3. ✅ Vérifier l'export en dark mode (si applicable)
4. ✅ Vérifier la lisibilité
5. ✅ Vérifier le temps de chargement

## Dépannage

### Le logo ne s'affiche pas

1. Vérifiez le chemin du fichier
2. Vérifiez les permissions du fichier
3. Vérifiez la console du navigateur (F12)
4. Essayez en mode navigation privée

### Le logo est déformé

```css
.logo {
  height: 50px;
  width: auto;        /* Important ! */
  object-fit: contain; /* Garde les proportions */
}
```

### Le logo est flou

- Utilisez un format vectoriel (SVG)
- Ou doublez la résolution du PNG (ex: 300x100 au lieu de 150x50)
- Ajoutez `image-rendering: -webkit-optimize-contrast;`

---

**Besoin d'aide ?** Consultez la documentation CSS ou contactez l'équipe dev.
