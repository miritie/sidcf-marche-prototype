# SID-CF Module Marché

## 📋 Description

Module de gestion des marchés publics pour le système SID-CF (Système d'Information de la Direction du Contrôle Financier). Ce prototype permet de gérer l'intégralité du cycle de vie des marchés publics, de la planification (PPM) à la clôture, en passant par l'attribution et l'exécution.

## 🚀 Fonctionnalités

### Phase Planification
- **ECR-01A**: Import PPM depuis fichier Excel
- **ECR-01B**: Saisie manuelle de marchés hors PPM
- **ECR-01C**: Création de fiches marchés avec livrables détaillés

### Phase Contractualisation  
- **ECR-02A**: Gestion des procédures et PV
- **ECR-02B**: Suivi des recours et observations CF

### Phase Attribution
- **ECR-03A**: Attribution et décision du Contrôleur Financier
- **ECR-03B**: Définition des échéanciers et clés de répartition budgétaire

### Phase Exécution
- **ECR-04A**: Suivi des OS et décomptes
- **ECR-04B**: Gestion des avenants
- **ECR-04C**: Suivi des garanties et résiliations

### Phase Clôture
- **ECR-05**: Réceptions et clôture administrative

### Reporting
- **ECR-06**: Tableau de bord consolidé et exports

## 🛠️ Technologies

- **Frontend**: HTML5, CSS3 (design moderne avec variables CSS)
- **JavaScript**: Vanilla JS (pas de framework, léger et rapide)
- **Data**: JSON (prêt pour intégration Airtable)
- **Déploiement**: GitHub + Vercel

## 📦 Installation

### Prérequis
- Node.js (optionnel, pour serveur local)
- Git

### Installation locale

1. Cloner le repository
```bash
git clone https://github.com/votre-username/sid-cf-marche.git
cd sid-cf-marche
```

2. Lancer un serveur local (plusieurs options)

**Option A: Avec Python**
```bash
python -m http.server 8000
```

**Option B: Avec Node.js**
```bash
npx serve
```

**Option C: Avec VS Code Live Server**
- Installer l'extension "Live Server"
- Clic droit sur `index.html` > "Open with Live Server"

3. Ouvrir dans le navigateur
```
http://localhost:8000
```

## 🌐 Déploiement sur Vercel

### Via l'interface Vercel

1. Créer un compte sur [vercel.com](https://vercel.com)
2. Connecter votre repository GitHub
3. Importer le projet
4. Vercel détectera automatiquement la configuration
5. Déployer !

### Via la CLI Vercel

```bash
# Installer Vercel CLI
npm i -g vercel

# Se connecter
vercel login

# Déployer
vercel
```

## 📂 Structure du projet

```
sid-cf-marche/
├── index.html              # Page principale
├── css/
│   └── styles.css         # Styles avec charte graphique
├── js/
│   ├── app.js             # Logique principale
│   └── app-extended.js    # Fonctions étendues
├── data/
│   ├── marches.json       # Données des marchés
│   ├── ppm.json           # Données PPM
│   └── referentiels.json  # Référentiels et paramètres
├── assets/
│   └── logo.svg           # Logo (remplaçable)
├── README.md              # Ce fichier
└── vercel.json            # Configuration Vercel
```

## 🎨 Personnalisation

### Changer le logo

Remplacer le fichier `assets/logo.svg` par votre propre logo (formats acceptés: SVG, PNG, JPG)

### Modifier la charte graphique

Éditer les variables CSS dans `css/styles.css`:

```css
:root {
  --primary-green: #4a7c59;      /* Couleur principale */
  --primary-green-light: #5fa677; /* Couleur secondaire */
  --accent-orange: #f39c12;       /* Accent */
  --accent-red: #e74c3c;          /* Danger */
  /* ... autres variables ... */
}
```

### Adapter les données

Éditer les fichiers JSON dans le dossier `data/`:
- `referentiels.json`: Unités, sections, programmes, bailleurs, etc.
- `marches.json`: Données des marchés
- `ppm.json`: Plan de Passation des Marchés

## 🔌 Intégration Airtable (prochaine étape)

Le projet est conçu pour une migration facile vers Airtable:

1. Créer une base Airtable avec les tables:
   - Marchés
   - PPM
   - Référentiels
   - Demandes

2. Remplacer les `fetch()` dans `js/app.js` par des appels API Airtable:

```javascript
// Avant (JSON local)
const response = await fetch('data/marches.json');

// Après (Airtable)
const response = await fetch('https://api.airtable.com/v0/BASE_ID/Marches', {
  headers: { 'Authorization': 'Bearer YOUR_API_KEY' }
});
```

## 📋 Règles de gestion implémentées

### Décision CF
- Blocage de l'exécution tant que Visa CF non accordé
- Motifs codifiés pour Réserve/Refus
- Traçabilité complète des décisions

### Avenants
- Seuil d'alerte à 25% (paramétrable)
- Seuil maximum à 30% (paramétrable)
- Calcul automatique du cumul

### Garanties
- Mainlevée possible uniquement après réception définitive
- Alertes sur échéances proches

### Clôture
- Impossible si garanties actives ou paiements en attente
- Marque automatique pour contrôle a posteriori

## 👥 Profils utilisateurs

- **Chargé d'études**: Saisie, préparation dossiers
- **Chef de service Marchés**: Vérification, validation
- **Contrôleur Financier**: Décisions (Visa/Réserve/Refus)

## 📊 Tableaux de bord

- Vue consolidée tous marchés
- Filtres multi-critères
- Indicateurs clés (KPIs)
- Alertes automatiques

## 🔐 Sécurité

Pour la production, ajouter:
- Authentification (OAuth, JWT)
- Autorisation par rôle (RBAC)
- HTTPS obligatoire
- Validation côté serveur

## 📝 License

Ce projet est un prototype de démonstration.

## 👨‍💻 Auteur

Développé pour la Direction du Contrôle Financier

## 🆘 Support

Pour toute question ou problème:
- Créer une issue sur GitHub
- Contacter l'équipe de développement

## 🗺️ Roadmap

- [ ] Authentification et gestion des utilisateurs
- [ ] Intégration Airtable
- [ ] Upload réel de fichiers (PPM Excel, PV, documents)
- [ ] Génération PDF des rapports
- [ ] Notifications par email
- [ ] Module de workflow avancé
- [ ] Export Excel des tableaux
- [ ] Interface mobile responsive améliorée
- [ ] Mode hors-ligne (PWA)
- [ ] Intégration module Budget
- [ ] Intégration module Contrôle a posteriori

---

**Version**: 1.0.0  
**Date**: Novembre 2024
