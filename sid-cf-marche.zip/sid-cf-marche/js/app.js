// Application State Management
const AppState = {
  currentScreen: 'dashboard',
  user: {
    nom: 'Jean KOUASSI',
    role: 'Administrateur'
  },
  data: {
    marches: [],
    referentiels: {},
    ppm: [],
    demandes: []
  },
  filters: {},
  selectedMarche: null
};

// Initialize Application
document.addEventListener('DOMContentLoaded', async () => {
  await loadData();
  initializeEventListeners();
  renderDashboard();
});

// Load Data from JSON files
async function loadData() {
  try {
    const [marchesRes, referentielsRes, ppmRes] = await Promise.all([
      fetch('data/marches.json'),
      fetch('data/referentiels.json'),
      fetch('data/ppm.json')
    ]);
    
    const marchesData = await marchesRes.json();
    const referentielsData = await referentielsRes.json();
    const ppmData = await ppmRes.json();
    
    AppState.data.marches = marchesData.marches || [];
    AppState.data.demandes = marchesData.demandes || [];
    AppState.data.referentiels = referentielsData;
    AppState.data.ppm = ppmData.ppmLignes || [];
    
    console.log('Data loaded successfully', AppState.data);
  } catch (error) {
    console.error('Error loading data:', error);
    showNotification('Erreur lors du chargement des données', 'danger');
  }
}

// Event Listeners
function initializeEventListeners() {
  // Navigation tabs
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      const screen = e.target.dataset.screen;
      if (screen) navigateToScreen(screen);
    });
  });
  
  // Logout button
  const logoutBtn = document.querySelector('.btn-deconnexion');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
  
  // Search functionality
  const searchInput = document.getElementById('search-marches');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.filters.search = e.target.value;
      renderMarches();
    });
  }
}

// Navigation
function navigateToScreen(screenName) {
  AppState.currentScreen = screenName;
  
  // Update active tab
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.classList.remove('active');
    if (tab.dataset.screen === screenName) {
      tab.classList.add('active');
    }
  });
  
  // Hide all screens
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });
  
  // Show active screen
  const activeScreen = document.getElementById(`screen-${screenName}`);
  if (activeScreen) {
    activeScreen.classList.add('active');
  }
  
  // Render screen content
  switch(screenName) {
    case 'dashboard':
      renderDashboard();
      break;
    case 'marches':
      renderMarches();
      break;
    case 'demandes':
      renderDemandes();
      break;
    case 'ppm':
      renderPPM();
      break;
    case 'parametres':
      renderParametres();
      break;
    case 'reports':
      renderReports();
      break;
  }
}

// Render Dashboard
function renderDashboard() {
  const stats = calculateStats();
  
  document.getElementById('stat-en-attente').textContent = stats.enAttente;
  document.getElementById('stat-en-validation').textContent = stats.enValidation;
  document.getElementById('stat-approuvees').textContent = stats.visa;
  document.getElementById('stat-montant-total').textContent = formatMoney(stats.montantTotal);
  
  renderMarchesTable('recent-marches-table', AppState.data.marches.slice(0, 5));
}

// Calculate Statistics
function calculateStats() {
  const marches = AppState.data.marches;
  return {
    enAttente: marches.filter(m => !m.attribution || !m.attribution.decisionCF).length,
    enValidation: marches.filter(m => m.statut === 'en_validation').length,
    visa: marches.filter(m => m.attribution && m.attribution.decisionCF === 'visa').length,
    reserve: marches.filter(m => m.attribution && m.attribution.decisionCF === 'reserve').length,
    montantTotal: marches.reduce((sum, m) => sum + (m.montantPrevisionnel || 0), 0),
    enExecution: marches.filter(m => m.statut === 'en_execution').length,
    clos: marches.filter(m => m.statut === 'clos').length
  };
}

// Render Marches List
function renderMarches() {
  const filteredMarches = applyFilters(AppState.data.marches);
  renderMarchesTable('marches-table-body', filteredMarches);
}

// Apply Filters
function applyFilters(marches) {
  let filtered = [...marches];
  
  if (AppState.filters.search) {
    const search = AppState.filters.search.toLowerCase();
    filtered = filtered.filter(m => 
      m.numero.toLowerCase().includes(search) ||
      m.intitule.toLowerCase().includes(search)
    );
  }
  
  if (AppState.filters.statut) {
    filtered = filtered.filter(m => m.statut === AppState.filters.statut);
  }
  
  if (AppState.filters.typeMarche) {
    filtered = filtered.filter(m => m.typeMarche === AppState.filters.typeMarche);
  }
  
  return filtered;
}

// Render Marches Table
function renderMarchesTable(tableId, marches) {
  const tableBody = document.getElementById(tableId);
  if (!tableBody) return;
  
  tableBody.innerHTML = marches.map(marche => `
    <tr style="cursor: pointer;">
      <td>${marche.numero}</td>
      <td>${marche.intitule}</td>
      <td>${getRefLabel('typesMarche', marche.typeMarche)}</td>
      <td>${getRefLabel('modesPassation', marche.modePassation)}</td>
      <td>${formatMoney(marche.montantPrevisionnel)}</td>
      <td>${renderStatusBadge(marche.statut)}</td>
      <td>${marche.attribution && marche.attribution.decisionCF ? renderDecisionBadge(marche.attribution.decisionCF) : '-'}</td>
      <td>
        <button class="btn btn-info btn-sm" onclick="viewMarche('${marche.id}')">
          Voir
        </button>
        <button class="btn btn-primary btn-sm" onclick="editMarche('${marche.id}')">
          Éditer
        </button>
      </td>
    </tr>
  `).join('');
}

// Render PPM
function renderPPM() {
  const tableBody = document.getElementById('ppm-table-body');
  if (!tableBody) return;
  
  tableBody.innerHTML = AppState.data.ppm.map((ligne, index) => `
    <tr>
      <td><input type="checkbox" id="ppm-${index}" ${ligne.importe ? 'checked disabled' : ''}></td>
      <td>${ligne.intituleOperation}</td>
      <td>${getRefLabel('unitesOperationnelles', ligne.unitOperationnelle)}</td>
      <td>${ligne.exercice}</td>
      <td>${formatMoney(ligne.montantPrevisionnel)}</td>
      <td>${ligne.trimestre}</td>
      <td>${ligne.importe ? '✓ Importé' : ligne.marcheAssocie ? '✓ Marché créé' : 'Non importé'}</td>
      <td>
        ${!ligne.importe && !ligne.marcheAssocie ? `
          <button class="btn btn-primary btn-sm" onclick="importPPMLigne(${index})">
            Importer
          </button>
        ` : ''}
      </td>
    </tr>
  `).join('');
}

// Import PPM Line
function importPPMLigne(index) {
  const ligne = AppState.data.ppm[index];
  if (!ligne) return;
  
  // Create new marche from PPM line
  const newMarche = {
    id: `M-${new Date().getFullYear()}-${String(AppState.data.marches.length + 1).padStart(3, '0')}`,
    numero: `M-${new Date().getFullYear()}-${String(AppState.data.marches.length + 1).padStart(3, '0')}`,
    intitule: ligne.intituleOperation,
    unitOperationnelle: ligne.unitOperationnelle,
    exercice: ligne.exercice,
    section: ligne.section,
    programme: ligne.programme,
    activite: ligne.activite,
    natureEconomique: ligne.natureEconomique,
    bailleur: ligne.bailleur,
    montantPrevisionnel: ligne.montantPrevisionnel,
    montantPrevisionnelHT: ligne.montantHT,
    montantPrevisionnelTTC: ligne.montantTTC,
    devise: 'FCFA',
    dureePrevisionnelle: ligne.dureePrevisionnelle,
    sourcePPM: 'import',
    statut: 'en_attente',
    livrables: [],
    typeMarche: 'TM-01',
    modePassation: 'AOO'
  };
  
  AppState.data.marches.push(newMarche);
  ligne.importe = true;
  ligne.marcheAssocie = newMarche.id;
  
  showNotification('Marché créé avec succès depuis le PPM', 'success');
  renderPPM();
}

// Render Demandes
function renderDemandes() {
  const tableBody = document.getElementById('demandes-table-body');
  if (!tableBody) return;
  
  tableBody.innerHTML = AppState.data.demandes.map(demande => `
    <tr style="cursor: pointer;">
      <td>${demande.numero}</td>
      <td>${demande.date}</td>
      <td>${demande.service}</td>
      <td><span class="status-badge ${demande.priorite.toLowerCase()}">${demande.priorite}</span></td>
      <td>${formatMoney(demande.montantEstime)}</td>
      <td><span class="status-badge ${demande.statut}">${translateStatus(demande.statut)}</span></td>
      <td>
        <button class="btn btn-info btn-sm" onclick="viewDemande('${demande.id}')">
          Voir
        </button>
        <button class="btn btn-warning btn-sm" onclick="transformDemande('${demande.id}')">
          Transformer
        </button>
      </td>
    </tr>
  `).join('');
}

// View Marche Details
function viewMarche(id) {
  const marche = AppState.data.marches.find(m => m.id === id);
  if (!marche) return;
  
  AppState.selectedMarche = marche;
  showModal('marche-detail-modal');
  renderMarcheDetail(marche);
}

// Render Marche Detail
function renderMarcheDetail(marche) {
  const content = document.getElementById('marche-detail-content');
  if (!content) return;
  
  content.innerHTML = `
    <div class="tabs">
      <button class="tab active" data-tab="general">Général</button>
      <button class="tab" data-tab="livrables">Livrables</button>
      <button class="tab" data-tab="attribution">Attribution & CF</button>
      <button class="tab" data-tab="execution">Exécution</button>
      <button class="tab" data-tab="cloture">Clôture</button>
    </div>
    
    <div id="marche-tab-content" class="mt-3">
      ${renderMarcheGeneralTab(marche)}
    </div>
  `;
  
  // Tab switching
  document.querySelectorAll('#marche-detail-content .tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.tab;
      document.querySelectorAll('#marche-detail-content .tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const tabContent = document.getElementById('marche-tab-content');
      switch(tabName) {
        case 'general':
          tabContent.innerHTML = renderMarcheGeneralTab(marche);
          break;
        case 'livrables':
          tabContent.innerHTML = renderMarcheLivrablesTab(marche);
          break;
        case 'attribution':
          tabContent.innerHTML = renderMarcheAttributionTab(marche);
          break;
        case 'execution':
          tabContent.innerHTML = renderMarcheExecutionTab(marche);
          break;
        case 'cloture':
          tabContent.innerHTML = renderMarcheClotureTab(marche);
          break;
      }
    });
  });
}

// Utility Functions
function formatMoney(amount) {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'XOF',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount || 0);
}

function formatDate(date) {
  if (!date) return '-';
  return new Date(date).toLocaleDateString('fr-FR');
}

function renderStatusBadge(status) {
  const labels = {
    'en_attente': 'En Attente',
    'en_validation': 'En Validation',
    'approuvee': 'Approuvée',
    'visa': 'Visa CF',
    'reserve': 'Réserve CF',
    'refus': 'Refus CF',
    'en_execution': 'En Exécution',
    'clos': 'Clos'
  };
  return `<span class="status-badge ${status}">${labels[status] || status}</span>`;
}

function renderDecisionBadge(decision) {
  const labels = {
    'visa': '✅ Visa',
    'reserve': '⚠️ Réserve',
    'refus': '❌ Refus'
  };
  return `<span class="status-badge ${decision}">${labels[decision] || decision}</span>`;
}

function translateStatus(status) {
  const labels = {
    'en_attente': 'En Attente',
    'en_validation': 'En Validation',
    'approuvee': 'Approuvée',
    'rejetee': 'Rejetée'
  };
  return labels[status] || status;
}

function getRefLabel(refType, code) {
  if (!code) return '-';
  const ref = AppState.data.referentiels[refType];
  if (!ref) return code;
  const item = ref.find(r => r.code === code);
  return item ? item.nom : code;
}

function showModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
  }
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `alert alert-${type}`;
  notification.textContent = message;
  notification.style.position = 'fixed';
  notification.style.top = '20px';
  notification.style.right = '20px';
  notification.style.zIndex = '9999';
  notification.style.minWidth = '300px';
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.remove();
  }, 5000);
}

function handleLogout() {
  if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
    showNotification('Déconnexion réussie', 'success');
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  }
}

// Additional functions will be in app-extended.js
