// Extended functions for detailed views and actions

// Render Marche General Tab
function renderMarcheGeneralTab(marche) {
  return `
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">N° Marché</label>
        <input type="text" class="form-control" value="${marche.numero}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Intitulé</label>
        <input type="text" class="form-control" value="${marche.intitule}" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Type de marché</label>
        <input type="text" class="form-control" value="${getRefLabel('typesMarche', marche.typeMarche)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Mode de passation</label>
        <input type="text" class="form-control" value="${getRefLabel('modesPassation', marche.modePassation)}" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Montant prévisionnel</label>
        <input type="text" class="form-control" value="${formatMoney(marche.montantPrevisionnel)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Durée prévisionnelle</label>
        <input type="text" class="form-control" value="${marche.dureePrevisionnelle} mois" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Unité opérationnelle</label>
        <input type="text" class="form-control" value="${getRefLabel('unitesOperationnelles', marche.unitOperationnelle)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Bailleur</label>
        <input type="text" class="form-control" value="${getRefLabel('bailleurs', marche.bailleur)}" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Section</label>
        <input type="text" class="form-control" value="${getRefLabel('sections', marche.section)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Programme</label>
        <input type="text" class="form-control" value="${getRefLabel('programmes', marche.programme)}" readonly>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Statut</label>
      <div>${renderStatusBadge(marche.statut)}</div>
    </div>
  `;
}

// Render Marche Livrables Tab
function renderMarcheLivrablesTab(marche) {
  if (!marche.livrables || marche.livrables.length === 0) {
    return '<p class="text-center">Aucun livrable enregistré</p>';
  }
  
  return `
    <table class="table">
      <thead>
        <tr>
          <th>Type</th>
          <th>Objet</th>
          <th>Localisation</th>
          <th>Bénéficiaire</th>
          <th>Volume</th>
        </tr>
      </thead>
      <tbody>
        ${marche.livrables.map(liv => `
          <tr>
            <td>${getRefLabel('typesLivrable', liv.type)}</td>
            <td>${liv.objet}</td>
            <td>${liv.region ? getRefLabel('regionsCI', liv.region) : '-'}<br>
                <small>${liv.commune || ''} ${liv.village || ''}</small>
            </td>
            <td>${liv.beneficiaire || '-'}</td>
            <td>${liv.volume || '-'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

// Render Marche Attribution Tab
function renderMarcheAttributionTab(marche) {
  if (!marche.attribution) {
    return '<p class="text-center">Pas encore d\'attribution</p>';
  }
  
  const attr = marche.attribution;
  return `
    <h4>Attributaire</h4>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Raison sociale</label>
        <input type="text" class="form-control" value="${attr.attributaire.raisonSociale}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">RCCM</label>
        <input type="text" class="form-control" value="${attr.attributaire.rccm}" readonly>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Contact</label>
        <input type="text" class="form-control" value="${attr.attributaire.telephone}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="text" class="form-control" value="${attr.attributaire.email}" readonly>
      </div>
    </div>
    
    <hr class="mt-3 mb-3">
    <h4>Montants</h4>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Montant d'attribution</label>
        <input type="text" class="form-control" value="${formatMoney(attr.montantAttribution)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Économie réalisée</label>
        <input type="text" class="form-control" value="${formatMoney(attr.economie)}" readonly>
      </div>
    </div>
    
    <hr class="mt-3 mb-3">
    <h4>Décision du Contrôleur Financier</h4>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Décision</label>
        <div>${attr.decisionCF ? renderDecisionBadge(attr.decisionCF) : 'En attente'}</div>
      </div>
      <div class="form-group">
        <label class="form-label">Date de décision</label>
        <input type="text" class="form-control" value="${formatDate(attr.dateDecisionCF)}" readonly>
      </div>
    </div>
    ${attr.commentaireDecision ? `
      <div class="form-group">
        <label class="form-label">Commentaire</label>
        <textarea class="form-control" readonly>${attr.commentaireDecision}</textarea>
      </div>
    ` : ''}
    
    ${!attr.decisionCF ? `
      <hr class="mt-3 mb-3">
      <h4>Rendre une décision</h4>
      <div class="form-group">
        <label class="form-label required">Décision</label>
        <select class="form-control" id="decision-cf">
          <option value="">-- Sélectionner --</option>
          <option value="visa">Visa</option>
          <option value="reserve">Réserve</option>
          <option value="refus">Refus</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label required">Motif</label>
        <select class="form-control" id="motif-decision">
          <option value="">-- Sélectionner --</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Commentaire</label>
        <textarea class="form-control" id="commentaire-decision" rows="4"></textarea>
      </div>
      <button class="btn btn-success" onclick="saveDecisionCF('${marche.id}')">
        ✅ Enregistrer la décision
      </button>
    ` : ''}
    
    ${marche.echeancier && marche.echeancier.length > 0 ? `
      <hr class="mt-3 mb-3">
      <h4>Échéancier de paiement</h4>
      <table class="table">
        <thead>
          <tr>
            <th>N°</th>
            <th>Montant</th>
            <th>Date prévisionnelle</th>
            <th>Statut</th>
          </tr>
        </thead>
        <tbody>
          ${marche.echeancier.map(ech => `
            <tr>
              <td>${ech.numero}</td>
              <td>${formatMoney(ech.montant)}</td>
              <td>${formatDate(ech.datePrevisionnelle)}</td>
              <td><span class="status-badge ${ech.statut}">${translateStatus(ech.statut)}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : ''}
  `;
}

// Render Marche Execution Tab
function renderMarcheExecutionTab(marche) {
  if (!marche.execution) {
    return '<p class="text-center">Pas encore d\'exécution</p>';
  }
  
  const exec = marche.execution;
  return `
    <h4>Ordre de Service</h4>
    ${exec.ordreService ? `
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">N° OS</label>
          <input type="text" class="form-control" value="${exec.ordreService.numero}" readonly>
        </div>
        <div class="form-group">
          <label class="form-label">Date OS</label>
          <input type="text" class="form-control" value="${formatDate(exec.ordreService.date)}" readonly>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Date de début</label>
          <input type="text" class="form-control" value="${formatDate(exec.ordreService.dateDebut)}" readonly>
        </div>
        <div class="form-group">
          <label class="form-label">Date de fin prévisionnelle</label>
          <input type="text" class="form-control" value="${formatDate(exec.ordreService.dateFinPrevisionnelle)}" readonly>
        </div>
      </div>
    ` : '<p>Aucun ordre de service enregistré</p>'}
    
    <hr class="mt-3 mb-3">
    <h4>Décomptes</h4>
    ${exec.decomptes && exec.decomptes.length > 0 ? `
      <table class="table">
        <thead>
          <tr>
            <th>N°</th>
            <th>Date</th>
            <th>Montant</th>
            <th>Cumul</th>
            <th>Retenue</th>
            <th>Net à payer</th>
            <th>Statut</th>
          </tr>
        </thead>
        <tbody>
          ${exec.decomptes.map(dec => `
            <tr>
              <td>${dec.numero}</td>
              <td>${formatDate(dec.date)}</td>
              <td>${formatMoney(dec.montant)}</td>
              <td>${formatMoney(dec.cumul)}</td>
              <td>${formatMoney(dec.retenueGarantie)}</td>
              <td>${formatMoney(dec.netAPayer)}</td>
              <td><span class="status-badge ${dec.statut}">${dec.statut === 'paye' ? '✅ Payé' : '⏳ En attente'}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      
      <div class="alert alert-info">
        <strong>Total payé:</strong> ${formatMoney(exec.decomptes.reduce((sum, d) => sum + d.montant, 0))}<br>
        <strong>Reste à payer:</strong> ${formatMoney((marche.attribution?.montantAttribution || 0) - exec.decomptes.reduce((sum, d) => sum + d.montant, 0))}
      </div>
    ` : '<p>Aucun décompte enregistré</p>'}
    
    ${marche.avenants && marche.avenants.length > 0 ? `
      <hr class="mt-3 mb-3">
      <h4>Avenants</h4>
      <table class="table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Date</th>
            <th>Variation montant</th>
            <th>Taux</th>
            <th>Motif</th>
          </tr>
        </thead>
        <tbody>
          ${marche.avenants.map(ave => `
            <tr>
              <td>${getRefLabel('typesAvenant', ave.type)}</td>
              <td>${formatDate(ave.date)}</td>
              <td>${formatMoney(ave.variationMontant)}</td>
              <td>${ave.tauxVariation}%</td>
              <td>${ave.motif}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : ''}
    
    ${marche.garanties && marche.garanties.length > 0 ? `
      <hr class="mt-3 mb-3">
      <h4>Garanties</h4>
      <table class="table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Montant</th>
            <th>Taux</th>
            <th>Date émission</th>
            <th>Date échéance</th>
            <th>Statut</th>
          </tr>
        </thead>
        <tbody>
          ${marche.garanties.map(gar => `
            <tr>
              <td>${getRefLabel('typesGarantie', gar.type)}</td>
              <td>${formatMoney(gar.montant)}</td>
              <td>${gar.taux}%</td>
              <td>${formatDate(gar.dateEmission)}</td>
              <td>${formatDate(gar.dateEcheance)}</td>
              <td><span class="status-badge ${gar.statut}">${gar.statut === 'active' ? '✅ Active' : '⏸️ Mainlevée'}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : ''}
  `;
}

// Render Marche Cloture Tab
function renderMarcheClotureTab(marche) {
  if (!marche.reception) {
    return '<p class="text-center">Pas encore de réception</p>';
  }
  
  return `
    <h4>Réception</h4>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Date de réception provisoire</label>
        <input type="text" class="form-control" value="${formatDate(marche.reception.dateProvisoire)}" readonly>
      </div>
      <div class="form-group">
        <label class="form-label">Date de réception définitive</label>
        <input type="text" class="form-control" value="${formatDate(marche.reception.dateDefinitive)}" readonly>
      </div>
    </div>
    
    <div class="alert alert-success mt-3">
      <strong>Marché clôturé</strong><br>
      Le marché a été réceptionné et clôturé avec succès.
    </div>
  `;
}

// Save Decision CF
function saveDecisionCF(marcheId) {
  const decision = document.getElementById('decision-cf').value;
  const motif = document.getElementById('motif-decision').value;
  const commentaire = document.getElementById('commentaire-decision').value;
  
  if (!decision) {
    showNotification('Veuillez sélectionner une décision', 'warning');
    return;
  }
  
  if (!motif) {
    showNotification('Veuillez sélectionner un motif', 'warning');
    return;
  }
  
  const marche = AppState.data.marches.find(m => m.id === marcheId);
  if (!marche || !marche.attribution) return;
  
  marche.attribution.decisionCF = decision;
  marche.attribution.motifDecision = motif;
  marche.attribution.commentaireDecision = commentaire;
  marche.attribution.dateDecisionCF = new Date().toISOString().split('T')[0];
  
  if (decision === 'visa') {
    marche.statut = 'en_execution';
  } else if (decision === 'reserve') {
    marche.statut = 'reserve';
  } else if (decision === 'refus') {
    marche.statut = 'refus';
  }
  
  showNotification('Décision enregistrée avec succès', 'success');
  closeModal('marche-detail-modal');
  renderDashboard();
}

// Edit Marche
function editMarche(id) {
  const marche = AppState.data.marches.find(m => m.id === id);
  if (!marche) return;
  
  showModal('edit-marche-modal');
  populateEditForm(marche);
}

// Populate Edit Form
function populateEditForm(marche) {
  // Implementation would populate a form modal for editing
  showNotification('Formulaire d\'édition en développement', 'info');
}

// View Demande
function viewDemande(id) {
  const demande = AppState.data.demandes.find(d => d.id === id);
  if (!demande) return;
  
  showNotification('Détail demande: ' + demande.numero, 'info');
}

// Transform Demande to Marche
function transformDemande(id) {
  const demande = AppState.data.demandes.find(d => d.id === id);
  if (!demande) return;
  
  if (confirm(`Transformer la demande ${demande.numero} en marché ?`)) {
    // Create new marche from demande
    const newMarche = {
      id: `M-${new Date().getFullYear()}-${String(AppState.data.marches.length + 1).padStart(3, '0')}`,
      numero: `M-${new Date().getFullYear()}-${String(AppState.data.marches.length + 1).padStart(3, '0')}`,
      intitule: demande.description,
      montantPrevisionnel: demande.montantEstime,
      statut: 'en_attente',
      sourcePPM: 'demande',
      // Other fields would be filled via form
    };
    
    AppState.data.marches.push(newMarche);
    showNotification('Marché créé avec succès', 'success');
    navigateToScreen('marches');
  }
}

// Render Parametres
function renderParametres() {
  const params = AppState.data.referentiels.parametres;
  const container = document.getElementById('parametres-content');
  
  if (!container) return;
  
  container.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">⚙️ Paramètres du système</h3>
      </div>
      <div class="card-body">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Seuil d'alerte avenants (%)</label>
            <input type="number" class="form-control" value="${params.seuilAlerteAvenants}" id="param-seuil-alerte">
          </div>
          <div class="form-group">
            <label class="form-label">Seuil maximum avenants (%)</label>
            <input type="number" class="form-control" value="${params.seuilMaxAvenants}" id="param-seuil-max">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Délai alerte sans OS (jours)</label>
            <input type="number" class="form-control" value="${params.delaiAlerteSansOS}" id="param-delai-os">
          </div>
          <div class="form-group">
            <label class="form-label">Délai alerte sans décompte (jours)</label>
            <input type="number" class="form-control" value="${params.delaiAlerteSansDecompte}" id="param-delai-decompte">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Taux de retenue de garantie (%)</label>
            <input type="number" class="form-control" value="${params.tauxRetenue}" id="param-taux-retenue">
          </div>
        </div>
        <button class="btn btn-success" onclick="saveParametres()">
          💾 Enregistrer les paramètres
        </button>
      </div>
    </div>
  `;
}

// Save Parametres
function saveParametres() {
  AppState.data.referentiels.parametres.seuilAlerteAvenants = parseInt(document.getElementById('param-seuil-alerte').value);
  AppState.data.referentiels.parametres.seuilMaxAvenants = parseInt(document.getElementById('param-seuil-max').value);
  AppState.data.referentiels.parametres.delaiAlerteSansOS = parseInt(document.getElementById('param-delai-os').value);
  AppState.data.referentiels.parametres.delaiAlerteSansDecompte = parseInt(document.getElementById('param-delai-decompte').value);
  AppState.data.referentiels.parametres.tauxRetenue = parseInt(document.getElementById('param-taux-retenue').value);
  
  showNotification('Paramètres enregistrés avec succès', 'success');
}

// Render Reports
function renderReports() {
  const container = document.getElementById('reports-content');
  if (!container) return;
  
  const stats = calculateStats();
  
  container.innerHTML = `
    <div class="stats-grid">
      <div class="stat-card green">
        <div class="stat-label">Total Marchés</div>
        <div class="stat-value">${AppState.data.marches.length}</div>
      </div>
      <div class="stat-card blue">
        <div class="stat-label">En Exécution</div>
        <div class="stat-value">${stats.enExecution}</div>
      </div>
      <div class="stat-card orange">
        <div class="stat-label">En Réserve</div>
        <div class="stat-value">${stats.reserve}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Clos</div>
        <div class="stat-value">${stats.clos}</div>
      </div>
    </div>
    
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">📊 Génération de rapports</h3>
      </div>
      <div class="card-body">
        <div class="form-row flex-gap">
          <button class="btn btn-primary" onclick="generateReport('marches')">
            📄 Rapport des marchés
          </button>
          <button class="btn btn-primary" onclick="generateReport('execution')">
            📈 Rapport d'exécution
          </button>
          <button class="btn btn-primary" onclick="generateReport('cf')">
            ✅ Rapport décisions CF
          </button>
          <button class="btn btn-primary" onclick="generateReport('budget')">
            💰 Rapport budgétaire
          </button>
        </div>
      </div>
    </div>
  `;
}

// Generate Report
function generateReport(type) {
  const labels = {
    'marches': 'Rapport des marchés',
    'execution': 'Rapport d\'exécution',
    'cf': 'Rapport décisions CF',
    'budget': 'Rapport budgétaire'
  };
  
  showNotification(`Génération du ${labels[type]} en cours...`, 'info');
  
  // Simulate report generation
  setTimeout(() => {
    showNotification(`${labels[type]} généré avec succès`, 'success');
  }, 2000);
}
